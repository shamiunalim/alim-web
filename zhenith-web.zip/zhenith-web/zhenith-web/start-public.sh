#!/data/data/com.termux/files/usr/bin/bash
set -e
cd "$(dirname "$0")"

for cmd in node npm ffmpeg cloudflared; do
  if ! command -v "$cmd" >/dev/null 2>&1; then
    echo "[BELUM ADA] $cmd"
    echo "Jalankan: bash setup-termux.sh"
    exit 1
  fi
done

if [ ! -d node_modules ] || [ ! -d node_modules/express ] || [ ! -d node_modules/multer ] || [ ! -d node_modules/adm-zip ]; then
  echo "Dependency belum lengkap. Memasang dependency..."
  npm install --no-audit --no-fund
  npm install --no-save --no-audit --no-fund adm-zip@0.5.16 express@5.1.0 multer@2.0.2
fi

node -e "import('express').then(()=>import('multer')).then(()=>import('adm-zip')).then(()=>console.log('Dependency: OK')).catch(e=>{console.error(e);process.exit(1)})"

echo
echo "========================================"
echo " ZHENITH DOWNLOADER WEB - PUBLIC"
echo "========================================"
echo "Local: http://127.0.0.1:3000"
echo "Starting server + Cloudflare Quick Tunnel..."
echo
exec node public.js
