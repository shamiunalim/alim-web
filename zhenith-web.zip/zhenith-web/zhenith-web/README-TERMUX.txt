ZHENITH WEB — CLEAN + PUBLIC + MUSIC

Fitur:
- Music Player manual (TIDAK auto play)
- Playlist, URL audio, upload audio
- APK Builder UI
- Public Web via Cloudflare Quick Tunnel
- Setup Termux otomatis untuk Node.js, FFmpeg, dan Cloudflared

CARA PALING MUDAH DI TERMUX

1. Masuk folder:
   cd /storage/emulated/0/ngentot

2. Jalankan setup sekali:
   bash setup-termux.sh

   Script akan memasang/mengecek:
   - Node.js / npm
   - FFmpeg
   - Cloudflared
   - dependency npm project

3. Jalankan public web:
   bash start-public.sh

   Tunggu sampai muncul:
   ZHENITH PUBLIC → https://xxxxx.trycloudflare.com

4. Buka URL tersebut dari browser/perangkat lain.

5. Untuk lokal saja:
   npm start
   lalu buka http://localhost:3000

PENTING
- Jangan tutup Termux selama public web digunakan.
- Quick Tunnel menghasilkan URL sementara.
- Browser tidak akan memutar musik otomatis; tekan Play.
- FFmpeg dipasang oleh setup script karena binary FFmpeg Android tidak aman/tepat untuk dibundel lintas perangkat.
