#!/data/data/com.termux/files/usr/bin/bash
set -e
cd "$(dirname "$0")"
echo "========================================"
echo " ZHENITH WEB - CLEAN TERMUX SETUP"
echo "========================================"
command -v pkg >/dev/null 2>&1 || { echo "ERROR: Jalankan script ini di Termux."; exit 1; }

echo "[1/5] Storage permission..."
termux-setup-storage || true

echo "[2/5] Update Termux package..."
pkg update -y

echo "[3/5] Install Node.js + FFmpeg..."
pkg install -y nodejs ffmpeg

echo "[4/5] Install Cloudflared..."
if ! command -v cloudflared >/dev/null 2>&1; then
  pkg install -y cloudflared
fi

echo "[5/5] Install web dependencies..."
npm install --no-audit --no-fund
npm install --no-save --no-audit --no-fund adm-zip@0.5.16 express@5.1.0 multer@2.0.2

node -e "import('express').then(()=>import('multer')).then(()=>import('adm-zip')).then(()=>console.log('DEPENDENCY CHECK: OK')).catch(e=>{console.error(e);process.exit(1)})"

echo
printf 'Node.js : '; node --version
printf 'npm     : '; npm --version
printf 'FFmpeg  : '; ffmpeg -version 2>/dev/null | head -n 1 || true
printf 'Tunnel  : '; cloudflared --version 2>/dev/null | head -n 1 || true

echo
echo "========================================"
echo " SETUP SELESAI"
echo " Jalankan: bash start-public.sh"
echo "========================================"
