ZHENITH DOWNLOADER WEB

1. Extract folder zhenith-web ke /storage/emulated/0/.
2. Termux:
   termux-setup-storage
   cd /storage/emulated/0/zhenith-web
3. Sekali saja:
   bash setup-termux.sh
4. Lokal:
   npm start
   buka http://127.0.0.1:3000
5. Public:
   bash start-public.sh
   buka URL https://....trycloudflare.com yang muncul.

API key disimpan di .env dan dipakai server, bukan frontend.
FFmpeg wajib untuk status/processing dan dipasang oleh setup script.
Jangan menutup Termux saat public tunnel dipakai.
