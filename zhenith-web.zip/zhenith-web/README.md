# Zhenith Downloader Web

Fitur:
- TikTok downloader
- Instagram downloader
- Facebook downloader
- YouTube downloader
- Video MP4 / Audio MP3
- Remove BG via remove.bg API
- File to URL via Catbox

## Termux

```bash
pkg update
pkg install nodejs ffmpeg
cd ~/zhenith-web
bash start-termux.sh
```

Buka `http://127.0.0.1:3000`.

### Remove BG
Set API key sebelum menjalankan server:

```bash
export REMOVE_BG_API_KEY='ISI_API_KEY_KAMU'
bash start-termux.sh
```

Jangan masukkan API key ke frontend atau upload ke GitHub.

### Public
Jika `cloudflared` sudah tersedia:

```bash
bash start-public.sh
```

Script ini memakai Quick Tunnel dan akan memberikan URL `trycloudflare.com`. Untuk domain sendiri gunakan Named Tunnel/Cloudflare Dashboard.
