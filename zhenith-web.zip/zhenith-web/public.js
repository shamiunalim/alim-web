import { spawn } from "child_process"
import http from "http"

const PORT = Number(process.env.PORT || 3000)

function waitForServer() {
  return new Promise(resolve => {
    const check = () => {
      const req = http.get(`http://127.0.0.1:${PORT}/api/status`, res => {
        res.resume()
        resolve(true)
      })
      req.on("error", () => setTimeout(check, 500))
      req.setTimeout(1000, () => req.destroy())
    }
    check()
  })
}

const server = spawn(process.execPath, ["server.js"], {
  stdio: ["ignore", "pipe", "pipe"],
  env: process.env
})
server.stdout.on("data", data => process.stdout.write(data))
server.stderr.on("data", data => process.stderr.write(data))
server.on("exit", code => {
  if (code && code !== 0) process.exitCode = code
})

await waitForServer()
console.log("\nZHENITH PUBLIC → Membuka Cloudflare Tunnel...\n")

const tunnel = spawn("cloudflared", ["tunnel", "--url", `http://127.0.0.1:${PORT}`], {
  stdio: ["ignore", "pipe", "pipe"],
  env: process.env
})

tunnel.stdout.on("data", data => process.stdout.write(data))
tunnel.stderr.on("data", data => process.stderr.write(data))
tunnel.on("error", err => {
  console.error("\nCloudflared tidak ditemukan.")
  console.error("Install dulu dengan: pkg install cloudflared -y")
  console.error("Setelah itu jalankan lagi: npm run public\n")
  server.kill()
  process.exit(1)
})

function stop() {
  tunnel.kill("SIGTERM")
  server.kill("SIGTERM")
}
process.on("SIGINT", stop)
process.on("SIGTERM", stop)
