ZHENITH WEB - MUSIC + PUBLIC WEB

1. Install Node.js jika belum ada:
   pkg install nodejs -y

2. Install Cloudflare Tunnel:
   pkg install cloudflared -y

3. Masuk folder project:
   cd /storage/emulated/0/ngentot

4. Install dependency:
   npm install

5. Jalankan lokal:
   npm start
   Buka http://localhost:3000

6. Jalankan PUBLIC:
   npm run public
   Tunggu sampai Cloudflare menampilkan URL https://....trycloudflare.com

7. Matikan server/public:
   tekan CTRL+C

Catatan autoplay:
Browser modern dapat memblokir autoplay audio bersuara sampai ada interaksi pengguna.
Player tetap memiliki tombol AUTO PLAY dan akan mencoba autoplay lagi setelah klik/touch pertama.
