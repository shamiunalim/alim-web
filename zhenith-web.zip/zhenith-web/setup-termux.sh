#!/data/data/com.termux/files/usr/bin/bash
set -e
cd "$(dirname "$0")"
echo "========================================"
echo " ZHENITH DOWNLOADER • TERMUX SETUP"
echo "========================================"
if command -v pkg >/dev/null 2>&1; then
  pkg update -y || true
  pkg install -y nodejs-lts ffmpeg curl || pkg install -y nodejs ffmpeg curl
fi
if ! command -v node >/dev/null 2>&1; then echo "Node.js belum tersedia."; exit 1; fi
if ! command -v ffmpeg >/dev/null 2>&1; then echo "FFmpeg gagal terpasang."; exit 1; fi
if ! command -v cloudflared >/dev/null 2>&1; then
  echo "Cloudflared belum ada. Mencoba memasang dari Termux..."
  pkg install -y cloudflared || true
fi
if ! command -v cloudflared >/dev/null 2>&1; then
  echo "Cloudflared belum tersedia dari repository Termux. Server lokal tetap siap."
  echo "Pasang cloudflared manual jika ingin public tunnel."
fi
npm install
node --check server.js
node --check script.js
printf "\nNode    : "; node -v
printf "FFmpeg  : "; ffmpeg -version | head -n 1
printf "Cloudflared: "; command -v cloudflared || echo "NOT FOUND"
echo "\nSETUP SELESAI."
echo "Lokal : npm start"
echo "Public: bash start-public.sh"
