#!/data/data/com.termux/files/usr/bin/bash
set -u
cd "$(dirname "$0")" || exit 1
clear
echo "=========================================="
echo "      ZHENITH DOWNLOADER WEB"
echo "=========================================="
command -v node >/dev/null 2>&1 || { echo "❌ Node.js belum ada. Jalankan: pkg install nodejs"; exit 1; }
command -v ffmpeg >/dev/null 2>&1 || { echo "📦 Menginstall ffmpeg..."; pkg install -y ffmpeg || exit 1; }
if ! command -v yt-dlp >/dev/null 2>&1; then
  echo "📦 yt-dlp belum ada. Mencoba install..."
  pkg install -y yt-dlp 2>/dev/null || python -m pip install -U yt-dlp || { echo "❌ Gagal install yt-dlp"; exit 1; }
fi
[ -d node_modules ] || npm install || exit 1
export HOST="0.0.0.0"
export PORT="${PORT:-3000}"
echo ""
echo "🌐 http://127.0.0.1:$PORT"
echo "📱 LAN: http://<IP-HP>:$PORT"
echo ""
node server.js
