const pages = {
  home: "Downloader",
  music: "Music Player",
  short: "Short Link",
  tourl: "Tourl",
  about: "About"
}

const $ = (id) => document.getElementById(id)

const state = {
  currentPage: "home",
  media: null
}

/* =========================
   NAVIGATION
========================= */

function openPage(page) {
  if (!pages[page]) page = "home"

  state.currentPage = page

  document.querySelectorAll(".page").forEach(el => {
    el.classList.toggle("active", el.id === page)
  })

  document.querySelectorAll(".nav").forEach(btn => {
    btn.classList.toggle("active", btn.dataset.page === page)
  })

  const title = $("pageTitle")
  if (title) title.textContent = pages[page]

  const sidebar = document.querySelector(".sidebar")
  if (sidebar) sidebar.classList.remove("open")
}

document.querySelectorAll(".nav").forEach(btn => {
  btn.addEventListener("click", () => {
    openPage(btn.dataset.page)
  })
})

const menuBtn = $("menuBtn")

if (menuBtn) {
  menuBtn.addEventListener("click", () => {
    document.querySelector(".sidebar")?.classList.toggle("open")
  })
}

/* =========================
   API HEALTH
========================= */

async function checkHealth() {
  const apiState = $("apiState")

  if (!apiState) return

  apiState.textContent = "Checking..."

  try {
    const res = await fetch("/api/health", {
      method: "GET",
      cache: "no-store"
    })

    const data = await res.json().catch(() => ({}))

    if (res.ok && data.ok !== false) {
      apiState.textContent = "● API Ready"
      apiState.classList.add("ready")
    } else {
      apiState.textContent = "● API Error"
      apiState.classList.remove("ready")
    }
  } catch {
    apiState.textContent = "● API Offline"
    apiState.classList.remove("ready")
  }
}

checkHealth()

/* =========================
   QUICK URL
========================= */

document.querySelectorAll("[data-example]").forEach(btn => {
  btn.addEventListener("click", () => {
    const input = $("urlInput")

    if (!input) return

    input.value = btn.dataset.example
    input.focus()
  })
})

/* =========================
   ESCAPE HTML
========================= */

function esc(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;")
}

/* =========================
   COPY
========================= */

async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text)
    return true
  } catch {
    try {
      const textarea = document.createElement("textarea")
      textarea.value = text
      textarea.style.position = "fixed"
      textarea.style.opacity = "0"

      document.body.appendChild(textarea)
      textarea.focus()
      textarea.select()

      const ok = document.execCommand("copy")

      textarea.remove()

      return ok
    } catch {
      return false
    }
  }
}

function copyButton(text) {
  const safe = esc(text)

  return `
    <button
      class="copy-btn"
      type="button"
      data-copy="${safe}">
      ⧉ Copy
    </button>
  `
}

document.addEventListener("click", async e => {
  const btn = e.target.closest("[data-copy]")

  if (!btn) return

  const text = btn.dataset.copy || ""
  const original = btn.innerHTML

  const ok = await copyText(text)

  btn.innerHTML = ok ? "✓ Copied" : "✕ Failed"

  setTimeout(() => {
    btn.innerHTML = original
  }, 1500)
})

/* =========================
   MEDIA NORMALIZER
========================= */

function normalizeMedia(data) {
  if (!data) return []

  let media = []

  if (Array.isArray(data.media)) {
    media = data.media
  } else if (Array.isArray(data.data)) {
    media = data.data
  } else if (Array.isArray(data.result)) {
    media = data.result
  } else if (data.data?.media && Array.isArray(data.data.media)) {
    media = data.data.media
  } else if (data.result?.media && Array.isArray(data.result.media)) {
    media = data.result.media
  }

  return media
    .map(item => {
      if (typeof item === "string") {
        return {
          url: item,
          type: detectMediaType(item)
        }
      }

      if (!item || typeof item !== "object") return null

      const url =
        item.url ||
        item.download ||
        item.download_url ||
        item.link ||
        item.src ||
        item.play ||
        item.video ||
        item.image ||
        item.photo

      if (!url) return null

      const type =
        item.type ||
        item.mime ||
        detectMediaType(url)

      return {
        ...item,
        url,
        type
      }
    })
    .filter(Boolean)
}

function detectMediaType(url) {
  const value = String(url || "").toLowerCase()

  if (
    value.includes(".mp4") ||
    value.includes(".webm") ||
    value.includes("video")
  ) {
    return "video"
  }

  if (
    value.includes(".mp3") ||
    value.includes(".m4a") ||
    value.includes(".wav") ||
    value.includes(".ogg") ||
    value.includes(".aac") ||
    value.includes("audio")
  ) {
    return "audio"
  }

  if (
    value.includes(".jpg") ||
    value.includes(".jpeg") ||
    value.includes(".png") ||
    value.includes(".webp") ||
    value.includes(".gif") ||
    value.includes("image")
  ) {
    return "image"
  }

  return "file"
}

/* =========================
   RENDER DOWNLOADER
========================= */

function render(data) {
  const result = $("result")

  if (!result) return

  if (!data) {
    result.innerHTML = ""
    return
  }

  if (data.ok === false) {
    result.innerHTML = `
      <div class="error-box">
        <strong>❌ Download gagal</strong>
        <p>${esc(data.message || data.error || "Terjadi kesalahan.")}</p>
      </div>
    `
    return
  }

  const media = normalizeMedia(data)

  const title =
    data.title ||
    data.name ||
    data.caption ||
    "Media berhasil ditemukan"

  const author =
    data.author ||
    data.uploader ||
    data.username ||
    ""

  const description =
    data.description ||
    data.desc ||
    ""

  let html = `
    <div class="result-box">

      <div class="result-head">
        <div>
          <small>RESULT</small>
          <h3>${esc(title)}</h3>
          ${author ? `<p>${esc(author)}</p>` : ""}
        </div>
      </div>
  `

  if (description) {
    html += `
      <div class="result-description">
        ${esc(description)}
      </div>
    `
  }

  if (
    data.thumbnail ||
    data.cover ||
    data.image
  ) {
    const thumbnail =
      data.thumbnail ||
      data.cover ||
      data.image

    html += `
      <img
        class="result-thumbnail"
        src="${esc(thumbnail)}"
        loading="lazy"
        onerror="this.style.display='none'">
    `
  }

  if (media.length) {
    html += `<div class="media-grid">`

    media.forEach((item, index) => {
      const url = item.url
      const type = String(item.type || detectMediaType(url)).toLowerCase()

      if (type.includes("video")) {
        html += `
          <div class="media-item">
            <video
              controls
              preload="metadata"
              src="${esc(url)}">
            </video>

            <div class="media-actions">
              ${copyButton(url)}
              <a
                class="download-btn"
                href="${esc(url)}"
                target="_blank"
                rel="noopener">
                ↓ Download
              </a>
            </div>
          </div>
        `
      } else if (type.includes("audio")) {
        html += `
          <div class="media-item">
            <audio
              controls
              preload="metadata"
              src="${esc(url)}">
            </audio>

            <div class="media-actions">
              ${copyButton(url)}
              <a
                class="download-btn"
                href="${esc(url)}"
                target="_blank"
                rel="noopener">
                ↓ Download
              </a>
            </div>
          </div>
        `
      } else if (type.includes("image")) {
        html += `
          <div class="media-item">
            <img
              src="${esc(url)}"
              loading="lazy"
              onerror="this.style.display='none'">

            <div class="media-actions">
              ${copyButton(url)}
              <a
                class="download-btn"
                href="${esc(url)}"
                target="_blank"
                rel="noopener">
                ↓ Download
              </a>
            </div>
          </div>
        `
      } else {
        html += `
          <div class="media-item file-item">
            <div class="file-icon">📁</div>

            <div class="media-actions">
              ${copyButton(url)}
              <a
                class="download-btn"
                href="${esc(url)}"
                target="_blank"
                rel="noopener">
                ↓ Download
              </a>
            </div>
          </div>
        `
      }
    })

    html += `</div>`
  } else if (data.url || data.download || data.link) {
    const url =
      data.url ||
      data.download ||
      data.link

    html += `
      <div class="single-result">
        <div class="single-url">
          ${esc(url)}
        </div>

        <div class="media-actions">
          ${copyButton(url)}

          <a
            class="download-btn"
            href="${esc(url)}"
            target="_blank"
            rel="noopener">
            ↓ Download
          </a>
        </div>
      </div>
    `
  } else {
    html += `
      <div class="empty-result">
        Tidak ada media yang ditemukan dari response API.
      </div>
    `
  }

  html += `</div>`

  result.innerHTML = html
}

/* =========================
   MAIN DOWNLOADER
========================= */

async function downloadMedia() {
  const input = $("urlInput")
  const button = $("downloadBtn")
  const result = $("result")

  if (!input || !button || !result) return

  const url = input.value.trim()

  if (!url) {
    result.innerHTML = `
      <div class="error-box">
        <strong>⚠️ URL kosong</strong>
        <p>Masukkan URL media terlebih dahulu.</p>
      </div>
    `
    input.focus()
    return
  }

  try {
    new URL(url)
  } catch {
    result.innerHTML = `
      <div class="error-box">
        <strong>⚠️ URL tidak valid</strong>
        <p>Pastikan URL diawali dengan http:// atau https://</p>
      </div>
    `
    input.focus()
    return
  }

  button.disabled = true
  button.dataset.oldText = button.textContent
  button.textContent = "Downloading..."

  result.innerHTML = `
    <div class="loading-box">
      <div class="loader"></div>
      <strong>Mengambil media...</strong>
      <p>Mohon tunggu sebentar.</p>
    </div>
  `

  try {
    const res = await fetch("/api/download", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        url,
        type: "auto"
      })
    })

    const data = await res.json().catch(() => ({
      ok: false,
      message: "Server mengirim response yang tidak valid."
    }))

    if (!res.ok) {
      data.ok = false
    }

    state.media = data
    render(data)

  } catch (err) {
    result.innerHTML = `
      <div class="error-box">
        <strong>❌ Server tidak dapat dihubungi</strong>
        <p>${esc(err.message || "Network error")}</p>
      </div>
    `
  } finally {
    button.disabled = false
    button.textContent =
      button.dataset.oldText || "Download"
  }
}

const downloadBtn = $("downloadBtn")

if (downloadBtn) {
  downloadBtn.addEventListener("click", downloadMedia)
}

const urlInput = $("urlInput")

if (urlInput) {
  urlInput.addEventListener("keydown", e => {
    if (e.key === "Enter") {
      e.preventDefault()
      downloadMedia()
    }
  })
}

/* =========================
   MUSIC PLAYER
   NO AUTOPLAY
========================= */

const audio = $("audio")
const musicUrl = $("musicUrl")
const musicAdd = $("musicAdd")
const trackTitle = $("trackTitle")
const trackSource = $("trackSource")

function addMusic(url) {
  if (!audio) return

  url = String(url || "").trim()

  if (!url) return

  try {
    new URL(url)
  } catch {
    if (trackTitle) {
      trackTitle.textContent = "URL tidak valid"
    }

    if (trackSource) {
      trackSource.textContent =
        "Masukkan URL audio yang benar."
    }

    return
  }

  /*
   * Penting:
   * Tidak menggunakan audio.play()
   * sehingga musik TIDAK autoplay.
   */

  audio.pause()
  audio.currentTime = 0
  audio.src = url
  audio.load()

  if (trackTitle) {
    trackTitle.textContent = "Music Ready"
  }

  if (trackSource) {
    trackSource.textContent = url
  }
}

if (musicAdd) {
  musicAdd.addEventListener("click", () => {
    addMusic(musicUrl?.value)
  })
}

if (musicUrl) {
  musicUrl.addEventListener("keydown", e => {
    if (e.key === "Enter") {
      e.preventDefault()
      addMusic(musicUrl.value)
    }
  })
}

/* =========================
   SHORT LINK
========================= */

async function shortenUrl() {
  const input = $("shortUrl")
  const button = $("shortBtn")
  const result = $("shortResult")

  if (!input || !button || !result) return

  const url = input.value.trim()

  if (!url) {
    result.innerHTML = `
      <div class="error-box">
        <strong>⚠️ URL kosong</strong>
        <p>Masukkan URL yang ingin dipendekkan.</p>
      </div>
    `
    input.focus()
    return
  }

  try {
    new URL(url)
  } catch {
    result.innerHTML = `
      <div class="error-box">
        <strong>⚠️ URL tidak valid</strong>
        <p>Masukkan URL lengkap dengan http:// atau https://</p>
      </div>
    `
    return
  }

  button.disabled = true
  button.dataset.oldText = button.textContent
  button.textContent = "Shortening..."

  result.innerHTML = `
    <div class="loading-box">
      <div class="loader"></div>
      <strong>Membuat short link...</strong>
    </div>
  `

  try {
    const res = await fetch("/api/short", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ url })
    })

    const data = await res.json().catch(() => ({
      ok: false,
      message: "Response server tidak valid."
    }))

    if (!res.ok || data.ok === false) {
      throw new Error(
        data.message ||
        data.error ||
        "Gagal membuat short link."
      )
    }

    const shortUrl =
      data.url ||
      data.shortUrl ||
      data.short_url ||
      data.result

    if (!shortUrl) {
      throw new Error(
        "Server tidak mengirim URL pendek."
      )
    }

    result.innerHTML = `
      <div class="short-result">
        <small>SHORT LINK</small>

        <div class="short-value">
          ${esc(shortUrl)}
        </div>

        <div class="media-actions">
          ${copyButton(shortUrl)}

          <a
            class="download-btn"
            href="${esc(shortUrl)}"
            target="_blank"
            rel="noopener">
            ↗ Open
          </a>
        </div>
      </div>
    `

  } catch (err) {
    result.innerHTML = `
      <div class="error-box">
        <strong>❌ Gagal</strong>
        <p>${esc(err.message || "Terjadi kesalahan.")}</p>
      </div>
    `
  } finally {
    button.disabled = false
    button.textContent =
      button.dataset.oldText || "Shorten"
  }
}

const shortBtn = $("shortBtn")

if (shortBtn) {
  shortBtn.addEventListener("click", shortenUrl)
}

const shortUrl = $("shortUrl")

if (shortUrl) {
  shortUrl.addEventListener("keydown", e => {
    if (e.key === "Enter") {
      e.preventDefault()
      shortenUrl()
    }
  })
}

/* =========================
   TOURL - FILE UPLOAD
========================= */

async function uploadTourl(file) {
  const result = $("tourlResult")

  if (!result) return

  if (!file) {
    result.innerHTML = `
      <div class="error-box">
        <strong>⚠️ File belum dipilih</strong>
      </div>
    `
    return
  }

  result.innerHTML = `
    <div class="loading-box">
      <div class="loader"></div>
      <strong>Mengupload file...</strong>
      <p>${esc(file.name)}</p>
    </div>
  `

  try {
    const form = new FormData()
    form.append("file", file)

    const res = await fetch("/api/tourl", {
      method: "POST",
      body: form
    })

    const data = await res.json().catch(() => ({
      ok: false,
      message: "Response server tidak valid."
    }))

    if (!res.ok || data.ok === false) {
      throw new Error(
        data.message ||
        data.error ||
        "Upload gagal."
      )
    }

    const url =
      data.url ||
      data.result ||
      data.link ||
      data.data?.url

    if (!url) {
      throw new Error(
        "Server tidak mengirim URL hasil upload."
      )
    }

    result.innerHTML = `
      <div class="short-result">
        <small>TOURL RESULT</small>

        <div class="short-value">
          ${esc(url)}
        </div>

        <div class="media-actions">
          ${copyButton(url)}

          <a
            class="download-btn"
            href="${esc(url)}"
            target="_blank"
            rel="noopener">
            ↗ Open
          </a>
        </div>
      </div>
    `

  } catch (err) {
    result.innerHTML = `
      <div class="error-box">
        <strong>❌ Upload gagal</strong>
        <p>${esc(err.message || "Terjadi kesalahan.")}</p>
      </div>
    `
  }
}

/* =========================
   TOURL - DRAG & DROP
========================= */

const tourlDrop = $("tourlDrop")

if (tourlDrop) {
  tourlDrop.addEventListener("click", () => {
    const input = document.createElement("input")

    input.type = "file"

    input.onchange = () => {
      if (input.files?.[0]) {
        uploadTourl(input.files[0])
      }
    }

    input.click()
  })

  tourlDrop.addEventListener("dragover", e => {
    e.preventDefault()
    tourlDrop.classList.add("dragover")
  })

  tourlDrop.addEventListener("dragleave", () => {
    tourlDrop.classList.remove("dragover")
  })

  tourlDrop.addEventListener("drop", e => {
    e.preventDefault()

    tourlDrop.classList.remove("dragover")

    const file = e.dataTransfer?.files?.[0]

    if (file) {
      uploadTourl(file)
    }
  })
}

/* =========================
   TOURL - URL
========================= */

async function tourlFromUrl() {
  const input = $("tourlUrlInput")
  const button = $("tourlUrlBtn")
  const result = $("tourlResult")

  if (!input || !button || !result) return

  const url = input.value.trim()

  if (!url) {
    result.innerHTML = `
      <div class="error-box">
        <strong>⚠️ URL kosong</strong>
        <p>Masukkan URL file terlebih dahulu.</p>
      </div>
    `
    return
  }

  try {
    new URL(url)
  } catch {
    result.innerHTML = `
      <div class="error-box">
        <strong>⚠️ URL tidak valid</strong>
      </div>
    `
    return
  }

  button.disabled = true
  button.dataset.oldText = button.textContent
  button.textContent = "Uploading..."

  result.innerHTML = `
    <div class="loading-box">
      <div class="loader"></div>
      <strong>Mengambil file dari URL...</strong>
    </div>
  `

  try {
    const res = await fetch("/api/tourl", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ url })
    })

    const data = await res.json().catch(() => ({
      ok: false,
      message: "Response server tidak valid."
    }))

    if (!res.ok || data.ok === false) {
      throw new Error(
        data.message ||
        data.error ||
        "Gagal membuat URL."
      )
    }

    const output =
      data.url ||
      data.result ||
      data.link ||
      data.data?.url

    if (!output) {
      throw new Error(
        "Server tidak mengirim URL hasil."
      )
    }

    result.innerHTML = `
      <div class="short-result">
        <small>TOURL RESULT</small>

        <div class="short-value">
          ${esc(output)}
        </div>

        <div class="media-actions">
          ${copyButton(output)}

          <a
            class="download-btn"
            href="${esc(output)}"
            target="_blank"
            rel="noopener">
            ↗ Open
          </a>
        </div>
      </div>
    `

  } catch (err) {
    result.innerHTML = `
      <div class="error-box">
        <strong>❌ Gagal</strong>
        <p>${esc(err.message || "Terjadi kesalahan.")}</p>
      </div>
    `
  } finally {
    button.disabled = false
    button.textContent =
      button.dataset.oldText || "Upload"
  }
}

const tourlUrlBtn = $("tourlUrlBtn")

if (tourlUrlBtn) {
  tourlUrlBtn.addEventListener("click", tourlFromUrl)
}

const tourlUrlInput = $("tourlUrlInput")

if (tourlUrlInput) {
  tourlUrlInput.addEventListener("keydown", e => {
    if (e.key === "Enter") {
      e.preventDefault()
      tourlFromUrl()
    }
  })
}

/* =========================
   KEYBOARD SHORTCUT
========================= */

document.addEventListener("keydown", e => {
  if (
    e.target.tagName === "INPUT" ||
    e.target.tagName === "TEXTAREA"
  ) {
    return
  }

  if (e.key === "1") {
    openPage("home")
  }

  if (e.key === "2") {
    openPage("music")
  }

  if (e.key === "3") {
    openPage("short")
  }

  if (e.key === "4") {
    openPage("tourl")
  }

  if (e.key === "5") {
    openPage("about")
  }
})

/* =========================
   DEFAULT PAGE
========================= */

openPage("home")