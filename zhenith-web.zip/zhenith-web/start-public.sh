#!/data/data/com.termux/files/usr/bin/bash
set -e
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then echo "Node.js belum terpasang. Jalankan: bash setup-termux.sh"; exit 1; fi
if ! command -v ffmpeg >/dev/null 2>&1; then echo "FFmpeg belum terpasang. Jalankan: bash setup-termux.sh"; exit 1; fi
if ! command -v cloudflared >/dev/null 2>&1; then echo "Cloudflared belum terpasang. Jalankan: bash setup-termux.sh"; exit 1; fi
if [ ! -d node_modules ]; then npm install; fi
PORT="${PORT:-3000}"
export PORT
cleanup(){ [ -n "$SERVER_PID" ] && kill "$SERVER_PID" 2>/dev/null || true; }
trap cleanup EXIT INT TERM
node server.js & SERVER_PID=$!
sleep 2
if ! kill -0 "$SERVER_PID" 2>/dev/null; then echo "Server gagal start."; exit 1; fi
echo ""
echo "ZHENITH DOWNLOADER PUBLIC"
echo "Local: http://127.0.0.1:$PORT"
echo "Public tunnel:"
echo ""
cloudflared tunnel --url "http://127.0.0.1:$PORT"
