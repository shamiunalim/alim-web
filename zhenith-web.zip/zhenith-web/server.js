import express from "express"
import multer from "multer"
import AdmZip from "adm-zip"
import fs from "fs"
import path from "path"
import os from "os"
import { spawn } from "child_process"
import { fileURLToPath } from "url"
import crypto from "crypto"

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)
const app = express()
const PORT = Number(process.env.PORT || 3000)
const uploadDir = path.join(__dirname, "uploads")
const projectDir = path.join(__dirname, "projects")
const buildDir = path.join(__dirname, "builds")
for (const dir of [uploadDir, projectDir, buildDir]) fs.mkdirSync(dir, { recursive: true })

const jobs = new Map()
const upload = multer({
  dest: uploadDir,
  limits: { fileSize: 200 * 1024 * 1024 },
  fileFilter: (req, file, cb) => file.originalname.toLowerCase().endsWith(".zip") ? cb(null, true) : cb(new Error("File harus berformat ZIP."))
})
app.use(express.json())
app.use(express.static(__dirname))

function findGradle() {
  const candidates = [
    process.env.GRADLE_HOME ? path.join(process.env.GRADLE_HOME, "bin", "gradle") : null,
    path.join(os.homedir(), ".zhenith-apk", "gradle", "gradle-8.7", "bin", "gradle"),
    "/home/container/tools/gradle/gradle-8.7/bin/gradle",
    "gradle"
  ].filter(Boolean)
  for (const cmd of candidates) if (cmd === "gradle" || fs.existsSync(cmd)) return cmd
  return null
}
function findAndroidSdk() {
  const candidates = [process.env.ANDROID_HOME, process.env.ANDROID_SDK_ROOT, path.join(os.homedir(), "Android", "Sdk"), "/home/container/android-sdk", "/opt/android-sdk", "/usr/local/android-sdk"].filter(Boolean)
  return candidates.find(dir => fs.existsSync(dir)) || null
}
function findAndroidProject(dir) {
  if (fs.existsSync(path.join(dir, "settings.gradle")) || fs.existsSync(path.join(dir, "settings.gradle.kts"))) return dir
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (!entry.isDirectory()) continue
    const child = path.join(dir, entry.name)
    if (fs.existsSync(path.join(child, "settings.gradle")) || fs.existsSync(path.join(child, "settings.gradle.kts"))) return child
  }
  return null
}
function safeExtract(zipPath, destination) {
  const zip = new AdmZip(zipPath)
  const root = path.resolve(destination)
  for (const entry of zip.getEntries()) {
    const target = path.resolve(root, entry.entryName)
    if (target !== root && !target.startsWith(root + path.sep)) throw new Error("ZIP mengandung path yang tidak aman.")
  }
  zip.extractAllTo(destination, true)
}
function findApk(dir) {
  const results = []
  function scan(current) {
    if (!fs.existsSync(current)) return
    for (const entry of fs.readdirSync(current, { withFileTypes: true })) {
      const full = path.join(current, entry.name)
      if (entry.isDirectory()) scan(full)
      else if (entry.name.toLowerCase().endsWith(".apk")) results.push(full)
    }
  }
  scan(dir)
  results.sort((a,b) => fs.statSync(b).mtimeMs - fs.statSync(a).mtimeMs)
  return results[0] || null
}
function addLog(job, text) {
  const clean = String(text).replace(/\r/g, "")
  if (!clean) return
  job.log += clean
  if (job.log.length > 500000) job.log = job.log.slice(-500000)
  for (const res of job.clients) res.write(`data: ${JSON.stringify({ type:"log", text:clean })}\n\n`)
}
function setProgress(job, progress, status) {
  job.progress = Math.max(0, Math.min(100, progress)); job.status = status
  for (const res of job.clients) res.write(`data: ${JSON.stringify({ type:"progress", progress:job.progress, status })}\n\n`)
}
function finishJob(job, payload) {
  job.done = true; job.result = payload
  for (const res of job.clients) { res.write(`data: ${JSON.stringify({ type:"done", ...payload })}\n\n`); res.end() }
  job.clients.clear()
}
function failJob(job, message, details="") {
  addLog(job, `\n\n❌ ${message}\n`)
  if (details) addLog(job, `\n${details}\n`)
  finishJob(job, { success:false, error:message, details })
}
function runGradle(job, command, args, cwd, env) {
  return new Promise((resolve, reject) => {
    addLog(job, `\n$ ${command} ${args.join(" ")}\n\n`)
    const child = spawn(command, args, { cwd, env, shell:false })
    let output = ""
    const timer = setTimeout(() => { child.kill("SIGTERM"); setTimeout(() => child.kill("SIGKILL"), 3000); reject(new Error("Build melebihi batas waktu 20 menit.")) }, 20 * 60 * 1000)
    const onData = data => { const text=data.toString(); output += text; addLog(job,text) }
    child.stdout.on("data", onData); child.stderr.on("data", onData)
    child.on("error", err => { clearTimeout(timer); reject(err) })
    child.on("close", code => { clearTimeout(timer); if (code===0) resolve(output); else { const err=new Error(`Gradle berhenti dengan exit code ${code}.`); err.output=output; reject(err) } })
  })
}
async function buildJob(job, file, originalName, buildType) {
  let projectPath = null
  try {
    setProgress(job,5,"Mengekstrak ZIP..."); addLog(job,`📦 Project: ${originalName}\n📂 Mengekstrak project...\n`)
    projectPath = path.join(projectDir, job.id); fs.mkdirSync(projectPath,{recursive:true}); safeExtract(file,projectPath)
    setProgress(job,15,"Mencari Android project...")
    const androidProject=findAndroidProject(projectPath)
    if (!androidProject) throw new Error("Android project tidak ditemukan. ZIP harus memiliki settings.gradle atau settings.gradle.kts.")
    addLog(job,`📁 Root Android: ${androidProject}\n`)
    const gradle=findGradle(); if (!gradle) throw new Error("Gradle tidak ditemukan. Install Gradle atau set GRADLE_HOME.")
    const sdk=findAndroidSdk(); if (!sdk) throw new Error("Android SDK tidak ditemukan. Set ANDROID_HOME atau ANDROID_SDK_ROOT.")
    addLog(job,`⚙️ Gradle: ${gradle}\n🤖 Android SDK: ${sdk}\n`)
    const env={...process.env,ANDROID_HOME:sdk,ANDROID_SDK_ROOT:sdk,GRADLE_USER_HOME:path.join(projectPath,".gradle")}
    const task=buildType==="release"?"assembleRelease":"assembleDebug"
    setProgress(job,25,`Menjalankan ${task}...`); addLog(job,`\n🚀 Build type: ${buildType.toUpperCase()}\n`)
    await runGradle(job,gradle,[task,"--no-daemon","--stacktrace"],androidProject,env)
    setProgress(job,90,"Mencari APK...")
    const apk=findApk(androidProject); if (!apk) throw new Error("Build selesai tetapi file APK tidak ditemukan.")
    const base=path.basename(originalName,path.extname(originalName)).replace(/[^a-zA-Z0-9._-]/g,"_")
    const outputName=`${base}-${buildType}-${job.id.slice(-6)}.apk`
    fs.copyFileSync(apk,path.join(buildDir,outputName))
    setProgress(job,100,"Build berhasil"); addLog(job,`\n✅ APK berhasil dibuat: ${outputName}\n`)
    finishJob(job,{success:true,message:"APK berhasil dibuat.",filename:outputName,download:`/api/download/${encodeURIComponent(outputName)}`})
  } catch(err) { failJob(job,err.message,err.output||"") }
  finally { try{fs.unlinkSync(file)}catch{}; if(projectPath)try{fs.rmSync(projectPath,{recursive:true,force:true})}catch{} }
}
app.post("/api/build",upload.single("project"),(req,res)=>{
  if(!req.file) return res.status(400).json({success:false,error:"ZIP project tidak ditemukan."})
  const id=`${Date.now()}-${crypto.randomBytes(4).toString("hex")}`
  const job={id,status:"Menyiapkan build...",progress:0,log:"",done:false,result:null,clients:new Set()}
  jobs.set(id,job)
  res.json({success:true,jobId:id})
  buildJob(job,req.file.path,req.file.originalname,req.body?.buildType==="release"?"release":"debug")
})
app.get("/api/build/:id/events",(req,res)=>{
  const job=jobs.get(req.params.id); if(!job) return res.status(404).end()
  res.setHeader("Content-Type","text/event-stream"); res.setHeader("Cache-Control","no-cache, no-transform"); res.setHeader("Connection","keep-alive"); res.flushHeaders?.()
  if(job.log) res.write(`data: ${JSON.stringify({type:"log",text:job.log})}\n\n`)
  res.write(`data: ${JSON.stringify({type:"progress",progress:job.progress,status:job.status})}\n\n`)
  if(job.done){res.write(`data: ${JSON.stringify({type:"done",...job.result})}\n\n`);return res.end()}
  job.clients.add(res); const heartbeat=setInterval(()=>res.write(": ping\n\n"),15000)
  req.on("close",()=>{clearInterval(heartbeat);job.clients.delete(res)})
})
app.get("/api/build/:id",(req,res)=>{const job=jobs.get(req.params.id);if(!job)return res.status(404).json({success:false,error:"Build tidak ditemukan."});res.json({success:true,jobId:job.id,progress:job.progress,status:job.status,done:job.done,result:job.result})})
app.get("/api/download/:file",(req,res)=>{const filename=path.basename(req.params.file);const file=path.join(buildDir,filename);if(!fs.existsSync(file))return res.status(404).send("APK tidak ditemukan.");res.download(file,filename)})
app.get("/api/status",(req,res)=>res.json({success:true,server:"online",node:process.version,gradle:!!findGradle(),androidSdk:!!findAndroidSdk(),activeBuilds:[...jobs.values()].filter(j=>!j.done).length}))
app.use((err,req,res,next)=>res.status(400).json({success:false,error:err.message}))
app.listen(PORT,"0.0.0.0",()=>console.log(`\nZHENITH WEB → http://localhost:${PORT}\n`))
